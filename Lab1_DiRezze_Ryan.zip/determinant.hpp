/******************************
** Program Name: Lab 1
** Author: Ryan DiRezze
** Date: September 30, 2018
** Description: Header file for the "determinant" function and implementation file,
   which is unused.
******************************/

// function prototype
int determinant(int** matrix, int size);
